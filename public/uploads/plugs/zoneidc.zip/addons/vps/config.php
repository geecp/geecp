<?php
return [
  // 接口地址
  'api_url' => 'https://www.zoneidc.com/api/cloudapi.asp',
  // 端口号
  'port' => 80,
];
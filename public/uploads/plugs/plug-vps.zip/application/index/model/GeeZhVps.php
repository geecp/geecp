<?php
namespace app\index\model;
use think\Model;

/**
 * 纵横VPS表
 */
class GeeZhVps extends Model
{
	
}

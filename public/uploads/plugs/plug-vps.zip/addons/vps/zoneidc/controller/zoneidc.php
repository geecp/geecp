<?php
namespace addons\vps\zoneidc\controller;
use think\Controller;
use think\Db;
use think\Config;
class zoneidc extends Controller{
    /**
     * 通用接口
     * @param $data  所传参数
     * @param $data['plug_id']  传入的接口产品id(将根据产品id去获取相关配置)
     * @param $data['data']  访问接口时的其余附带参数
     * @param $data['action']  即将访问的接口名称
     * @param $data['attach']  访问接口时附带的请求备注
     * @param $data['openX']   访问接口时附带的?
     * @return json
     */
    public function control($data=[]){
      $ret = [
        'status'=>200,
        'msg'=>'操作成功！',
        'data'=>''
      ];
      if(empty($data['action']) || !isset($data['action'])){
        $ret['status'] = 422;
        $ret['msg'] = '请求接口异常！接口不存在。';
        return $ret;
      }
      // $_URI = Config::get('api_url');
      $_URI = 'https://www.zoneidc.com/api/cloudapi.asp';
      $product = Db::name('gee_product')->where('id = '.$data['plug_id'])->find();
      $config = json_decode($product['plug_config'],true);
      $data['userid'] = $config['user'];
      //([原密码+7i24.com] md5 32位)
      $data['userstr'] = md5($config['password'].'7i24.com');
      // dump($config['password'].'7i24.com');
      // dump($data);
      // dump(convertUrlQuery($dd));
      // exit;
      switch($data['action']){
        case 'getinfo':
        //假如是查询接口
        $url = $_URI.'?userid='.$data["userid"].'&userstr='.$data['userstr'].'&vpsname='.(isset($data['data']['vpsname'])?$data['data']['vpsname']:'').'&action='.$data['action'].'&attach='.$data['attach'].'openX='.$data['openX'];
        break; 
        case 'activate':
        $url = $_URI.'?userid='.$data["userid"].'&userstr='.$data['userstr'].'&year='.$data['data']['year'].'&idc='.(isset($data['data']['idc'])?$data['data']['idc']:'').'&productid='.$config['product_id'].'&action='.$data['action'].'&attach='.$data['attach'];
        break;
      }
      $res = $this->send($url);
      $res = convertUrlQuery($res);

      if($res['ret'] == '0'){
        $ret['status'] = 401;
        $ret['msg'] = $res['freehosinfo'];
        return json_encode($ret);
      }
      $saveData = [
        'user_id'=> $this->_userInfo['id'],
        'product_id'=> $pro_id,
        'name'=> $res['vpsname'],
        'password'=>$res['vpspassword'],
        'attach'=>$res['attach'],
        'end_time'=>$res['endtime'],
        'ip'=> get_ip(),
        'status'=> 1,
        'create_time'=>time(),
        'update_time'=>time(),
      ];
      $saveres = Db::name('gee_product')->insert($saveData);
      // $saveres = $zhvps->save($saveData);
      if($saveres){
        return json_encode($ret);
      } else {
        $ret['status'] = 500;
        $ret['msg'] = '操作超时！';
      }
      return json_encode($ret);
    }

    /**
     * curl 调用接口
     * @param $aData
     * @return \SimpleXMLElement
     */
    private function send($_URI='',$Data=''){
      $curl = curl_init();
      curl_setopt($curl, CURLOPT_URL, $_URI);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
      curl_setopt($curl, CURLOPT_POST, true);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $Data);
      $return =  curl_exec($curl);
      // dump(mb_convert_encoding($return,'utf-8','GB2312'));
      return mb_convert_encoding($return,'utf-8','GB2312');
  }
}